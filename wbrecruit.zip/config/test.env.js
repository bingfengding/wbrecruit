
// const merge = require('webpack-merge')
// const devEnv = require('./dev.env')
'use strict'

module.exports = {
  NODE_ENV: '"testing"',
  ENV_CONFIG: '"test"',
  BASE_API:'"http://10.5.35.135:8080"'
}
